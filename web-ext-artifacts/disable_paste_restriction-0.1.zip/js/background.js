class BG {

    constructor(){

    }

    static init(){
        let bg = new BG();
    }
}

$(function () {
   BG.init();
});